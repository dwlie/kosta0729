# spring-boot-developer
# Q&A
실습 진행 도중에 생긴 오류 해결에 어려움을 겪는다면 [이슈](https://github.com/shinsunyoung/springboot-developer/issues)를 등록해주시거나 [오픈카톡](https://open.kakao.com/o/gE422Qtf)으로 문의 주시면 최대한 빠르게 답변 드릴 수 있도록 하겠습니다.

## 이슈 등록 방법
<img width="1473" alt="image" src="https://github.com/shinsunyoung/springboot-developer/assets/42836576/dd15337b-7ac2-488d-85ff-f13b5d2fcbf4">
01. [New issue] 클릭

<img width="1665" alt="image" src="https://github.com/shinsunyoung/springboot-developer/assets/42836576/70ce0394-6589-465c-b408-6a57dafec4e7">
02. 이슈 제목/내용을 적고 [Submit new issue] 클릭

+ [closed issue](https://github.com/shinsunyoung/springboot-developer/issues?q=is%3Aissue+is%3Aclosed)에는 이미 해결된 이슈들이 있습니다. 참고하시어 문제를 해결하시면 보다 빠르게 해결이 가능합니다.
